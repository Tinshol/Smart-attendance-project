# smart-attendance-system
The model.py is responsible for the user interface,
The attendance_project.py file initiates the webcam using opencv 
The face is detected and recognised using face-recognition
Then the attendance is written to a attendance.csv file with date and time.
